/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.product;
import java.util.Scanner;
/**
 *
 * @author Student
 */

public class ProductSalesReport {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Single-dimensional array for the three mattress products
        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };
        // Two-dimensional array for sales over 3 months (3 products x 3 months)
        int[][] sales = new int[products.length][3];
        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                System.out.print("Enter number of sales for month " +(j + 1)+ " for " + products[i] + "mattress: )";
                sales[i][j] = scanner.nextInt();
            }
            System.out.println();
        }
        Product product = new Product(products, sales);
        PrintProduct printer = new PrintProduct(product);
        printer.printReport();
        scanner.close();
    }
}