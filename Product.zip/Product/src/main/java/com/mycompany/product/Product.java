/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.product;

/**
 *
 * @author Student
 */
public class Product implements IProduct {
    private String[] products;
    private int[][] sales;
    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++){
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
        }
        }
                
        return total;
    }
    @Override
    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = 0;
        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length;
        }
        if (count == 0) {
            return 0.0;
        }
        return (double) total / count;
    }
    @Override
    public String GetMostPopularProduct() {
        int maxSales = sales[0][0];
        String popularProduct = products[0];
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                if (sales[i][j] > maxSales) {
                    maxSales = sales[i][j];
                    popularProduct = products[i];
                }
            }
        }
        return popularProduct + " (" + maxSales + ")";
    }
}
   
