/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productapp;

/**
 *
 * @author Student
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;



public class ProductApp extends JFrame {
    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;
    public ProductApp() {
        initComponents();
    }
    private void initComponents() {
        setTitle("Product App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        // Menu System 
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        processItem.addActionListener(e -> processSale());
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
        
        
        // Form Layout 
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        // Customer Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Customer Name:"), gbc);
        gbc.gridx = 1;
        txtCustomerName = new JTextField(20);
        panel.add(txtCustomerName, gbc);
        
        // Select Product
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Select Product:"), gbc);
        gbc.gridx = 1;
        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };
        cmbProduct = new JComboBox<>(products);
        panel.add(cmbProduct, gbc);
        
        // Enter Price
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Enter Price:"), gbc);
        gbc.gridx = 1;
        txtPrice = new JTextField(20);
        panel.add(txtPrice, gbc);
        
        
        // Process Button
        gbc.gridx = 1;
        gbc.gridy = 3;
        btnProcess = new JButton("PROCESS");
        btnProcess.addActionListener(e -> processSale());
        panel.add(btnProcess, gbc);
        add(panel);
        pack();
        setLocationRelativeTo(null);
    }
    // Shared processing logic for Button and Tools -> Process menu item
    private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();
        String priceText = txtPrice.getText().trim();
        if (customerName.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter both the customer name and product price.",
                "Input Error",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter a valid numeric price.",
                "Invalid Price",
                JOptionPane.ERROR_MESSAGE
            );
        }
            return;
        ProductCalculations calculations = new ProductCalculations (price);
        double vat = calculations.GetVat();
        double commission = calculations.GetCommission();
        double total = calculations.GetTotal();
        String output = "Customer Name: " + customerName + "\n"
                      + "Product: " + product + "\n"
                      + "VAT: R " + vat + "\n"
                      + "COMMISSION: R " + commission + "\n"
                      + "TOTAL: R " + total;
        JOptionPane.showMessageDialog(
            this,
            output,
            "Message",
            JOptionPane.INFORMATION_MESSAGE
        );
        saveToFile(output);
    }
    // Saves formatted log to data into a file
    private void saveToFile(String details) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt", true))) {
            writer.println("DATA LOG");
            writer.println("******************************");
            writer.println(details);
            writer.println("******************************");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error saving to data.txt: " + ex.getMessage(),
                "File Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    // Clears text fields and resets combo box to index 0 
    private void clearForm() {
        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}